import React, { useState, useEffect } from 'react';
import Papa from 'papaparse';
import axios from 'axios';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts';
import './index.css';

function csvToJson(csvText) {
  const parsed = Papa.parse(csvText, { header: true, dynamicTyping: true, skipEmptyLines: true });
  return parsed.data;
}

function jsonToCsv(json) {
  return Papa.unparse(json);
}

function downloadFile(filename, content) {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export default function App() {
  const [rawCsv, setRawCsv] = useState(null);
  const [data, setData] = useState([]);
  const [census, setCensus] = useState([]);
  const [merged, setMerged] = useState([]);
  const [previewRows, setPreviewRows] = useState(10);
  const [stateFips, setStateFips] = useState('12');
  const [year, setYear] = useState('2021');
  const [loadingCensus, setLoadingCensus] = useState(false);
  const [filterText, setFilterText] = useState('');

  useEffect(() => {
    if (data.length > 0 && census.length > 0) {
      const left = data;
      const right = census;
      const rightIndex = {};
      right.forEach(r => {
        if (r.county && r.state) rightIndex[`${r.state}-${r.county}`] = r;
        if (r.NAME) rightIndex[r.NAME.toLowerCase()] = r;
      });
      const mergedRows = left.map(l => {
        const key1 = (l.state && l.county) ? `${String(l.state).padStart(2,'0')}-${String(l.county).padStart(3,'0')}` : null;
        const match = (key1 && rightIndex[key1]) || (l.county_name && rightIndex[l.county_name.toLowerCase()]) || rightIndex[l.NAME && l.NAME.toLowerCase()];
        return { ...l, census: match || null };
      });
      setMerged(mergedRows);
    }
  }, [data, census]);

  async function handleUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    setRawCsv(file.name);
    const text = await file.text();
    const json = csvToJson(text);
    setData(json);
  }

  function dropMissing(column) {
    const filtered = data.filter(row => row[column] !== null && row[column] !== '' && row[column] !== undefined);
    setData(filtered);
  }

  function convertToNumber(column) {
    const converted = data.map(r => ({ ...r, [column]: r[column] === '' || r[column] === null ? null : Number(r[column]) }));
    setData(converted);
  }

  async function fetchCensus() {
    setLoadingCensus(true);
    try {
      const resp = await axios.get(`/api/get-census`, { params: { year, dataset: 'acs/acs5', state: stateFips, vars: 'B01003_001E' } });
      let json = resp.data;
      const header = json[0];
      const rows = json.slice(1).map(r => {
        const obj = {};
        header.forEach((h, i) => { obj[h] = r[i]; });
        return obj;
      });
      setCensus(rows);
    } catch (err) {
      console.error('Census fetch error', err);
      alert('Failed to fetch Census data — check server and CENSUS_API_KEY');
    } finally {
      setLoadingCensus(false);
    }
  }

  const displayed = (merged.length ? merged : data).filter(r => {
    if (!filterText) return true;
    return Object.values(r).join(' ').toLowerCase().includes(filterText.toLowerCase());
  }).slice(0, previewRows);

  const chartData = (merged.length ? merged : data).slice(0, 100).map((r, idx) => {
    const x = r.NAME || r.county_name || `row${idx}`;
    const y = r.census ? Number(r.census.B01003_001E) : (r.TotalRevenue ? Number(r.TotalRevenue) : null);
    return { name: x, value: isNaN(y) ? null : y };
  }).filter(d => d.value !== null);

  return (
    <div className="min-h-screen p-6 bg-slate-50 text-slate-900">
      <div className="max-w-5xl mx-auto">
        <header className="mb-6">
          <h1 className="text-2xl font-bold">Data Wrangling App — Windsurf</h1>
          <p className="text-sm text-slate-600">Upload CSV, fetch Census context, merge, visualize, and export.</p>
        </header>

        <section className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-white rounded shadow">
            <h2 className="font-semibold">1. Upload CSV</h2>
            <input aria-label="upload-csv" type="file" accept=".csv" onChange={handleUpload} className="mt-2" />
            <div className="mt-2 text-sm text-slate-600">{rawCsv ? `Loaded: ${rawCsv}` : 'No file loaded'}</div>
            <div className="mt-3">
              <button className="px-3 py-1 rounded bg-indigo-600 text-white text-sm" onClick={() => { if (data.length===0) return alert('Upload a CSV first'); dropMissing('id'); }}>Drop missing "id"</button>
              <button className="ml-2 px-3 py-1 rounded bg-slate-200 text-sm" onClick={() => { if (data.length===0) return alert('Upload a CSV first'); convertToNumber('Quantity'); }}>Convert Quantity → number</button>
            </div>
          </div>

          <div className="p-4 bg-white rounded shadow">
            <h2 className="font-semibold">2. Census Context (server proxy)</h2>
            <label className="block text-xs text-slate-600">State FIPS</label>
            <input value={stateFips} onChange={e=>setStateFips(e.target.value)} className="border p-1 rounded w-full mt-1 text-sm" />
            <label className="block text-xs text-slate-600 mt-2">Year</label>
            <input value={year} onChange={e=>setYear(e.target.value)} className="border p-1 rounded w-full mt-1 text-sm" />
            <div className="mt-3">
              <button disabled={loadingCensus} onClick={fetchCensus} className="px-3 py-1 rounded bg-green-600 text-white">Fetch Census</button>
            </div>
            <div className="mt-2 text-sm text-slate-600">{census.length ? `${census.length} census rows` : 'No census fetched'}</div>
          </div>

          <div className="p-4 bg-white rounded shadow">
            <h2 className="font-semibold">3. Export / Controls</h2>
            <label className="block text-xs text-slate-600">Preview rows</label>
            <input type="range" min={5} max={100} value={previewRows} onChange={e=>setPreviewRows(Number(e.target.value))} />
            <div className="mt-3">
              <button className="px-3 py-1 rounded bg-blue-600 text-white" onClick={()=>{ const csv = jsonToCsv(merged.length?merged:data); downloadFile('cleaned.csv', csv); }}>Download CSV</button>
            </div>
            <div className="mt-3">
              <input placeholder="quick filter" value={filterText} onChange={e=>setFilterText(e.target.value)} className="border p-1 rounded w-full text-sm" />
            </div>
          </div>
        </section>

        <main>
          <section className="mb-6 p-4 bg-white rounded shadow">
            <h3 className="font-semibold mb-2">Data Preview</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-slate-100">
                  <tr>
                    {(displayed[0] ? Object.keys(displayed[0]) : ['No data']).slice(0,10).map((h,i)=> (
                      <th key={i} className="p-2 text-left font-medium">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {displayed.map((row, r) => (
                    <tr key={r} className="border-t">
                      {Object.values(row).slice(0,10).map((v, c) => (
                        <td key={c} className="p-2">{typeof v === 'object' ? JSON.stringify(v).slice(0,80) : String(v)}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section className="mb-6 p-4 bg-white rounded shadow">
            <h3 className="font-semibold mb-2">Simple Chart</h3>
            <div style={{ width: '100%', height: 300 }}>
              <ResponsiveContainer>
                <LineChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" hide={chartData.length>20} />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="value" stroke="#2563EB" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </section>
        </main>

        <footer className="mt-6 text-xs text-slate-500">
          <div>Deploy notes: Use Windsurf App Deploys. Ensure CENSUS_API_KEY is set in Windsurf environment variables.</div>
        </footer>
      </div>
    </div>
  );
}
