// server/index.js
const express = require('express');
const fetch = require('node-fetch');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Proxy route for Census API
app.get('/api/get-census', async (req, res) => {
  try {
    const { year = '2021', dataset = 'acs/acs5', state = '12', vars = 'B01003_001E' } = req.query;
    const key = process.env.CENSUS_API_KEY;
    if (!key) return res.status(500).send({ error: 'CENSUS_API_KEY not configured' });

    const base = `https://api.census.gov/data/${year}/${dataset}`;
    const params = new URLSearchParams({ get: `${vars},NAME`, for: 'county:*', in: `state:${state}`, key });
    const url = `${base}?${params.toString()}`;

    const r = await fetch(url, { timeout: 30000 });
    const text = await r.text();
    try {
      const json = JSON.parse(text);
      return res.status(r.status).json(json);
    } catch (err) {
      return res.status(r.status).send(text);
    }
  } catch (err) {
    console.error('Proxy error', err);
    return res.status(500).send({ error: String(err) });
  }
});

// Serve static built frontend
const distPath = path.join(__dirname, '..', 'dist');
app.use(express.static(distPath));
app.get('*', (req, res) => res.sendFile(path.join(distPath, 'index.html')));

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
